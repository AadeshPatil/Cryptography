package com.kleem.bullet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BulletHealthCareApplicationTests {

	@Test
	void contextLoads() {
	}

}
